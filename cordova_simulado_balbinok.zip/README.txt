Cordova Simulado ACCESS (@balbinokdiupe)
1) npm i -g cordova
2) cordova platform add android@12
3) cordova build android
APK: platforms/android/app/build/outputs/apk/debug/app-debug.apk
